import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { parse, queryTerms } from "../src/query/parser.js";

const root = fileURLToPath(new URL("../data/courtlistener-brief-research/", import.meta.url));
const rows = readFileSync(root + "queries.jsonl", "utf8").trim().split("\n").map(line => JSON.parse(line));
const manifest = JSON.parse(readFileSync(root + "manifest.json", "utf8"));
const expected = Number(process.argv[2] ?? manifest.exported_rows ?? 1000);
const failures: { brief_id: string; error: string }[] = [];
const termCounts: number[] = [];
let rootExpansionQueries = 0;
for (const row of rows) {
  try {
    if (manifest.selection_filter && !manifest.selection_filter.kept_query_styles.includes(row.query_style)) {
      throw new Error(`Excluded query style: ${row.query_style}`);
    }
    // The application parser rejects Lexis root expanders. Check their placement
    // separately, then check only the expression structure using the bare root.
    // This does not execute expansion or establish Lexis search equivalence.
    const expanded = row.query.replace(/\b([A-Za-z]{3,})!(?=$|\s|[)])/g, "$1");
    if (expanded !== row.query) rootExpansionQueries++;
    const ast = parse(expanded);
    if (ast.kind === "empty") throw new Error("Empty query");
    termCounts.push(queryTerms(ast).length);
  } catch (error) {
    failures.push({ brief_id: row.brief_id, error: String(error) });
  }
}
const report = {
  rows: rows.length,
  unique_brief_ids: new Set(rows.map(r => r.brief_id)).size,
  unique_queries: new Set(rows.map(r => r.query)).size,
  parsed_successfully: termCounts.length,
  max_distinct_terms: Math.max(...termCounts),
  max_query_characters: Math.max(...rows.map(r => r.query.length)),
  root_expansion_queries_checked_with_bare_roots: rootExpansionQueries,
  scope: "Local expression structure and complexity only. Validly placed Lexis root expanders are removed before parsing; expansion is not executed. Not Lexis execution or retrieval validation.",
  failures,
};
writeFileSync(root + "syntax-validation.json", JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify(report, null, 2));
if (failures.length || rows.length !== expected || report.unique_brief_ids !== expected) process.exitCode = 1;
