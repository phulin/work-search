#!/usr/bin/env python3
"""Build the research-query dataset offline from pinned source and authored queries."""

import csv
import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "data/stanford-bar-research"
REVISION = "b7c245a7e4739f6c785faa2489e283c8daa449d1"
SOURCE_HASHES = {
    "qa.csv": "01589a7c02740cd525da73a54a599dff66a4999864e66d1c803405e338e193be",
    "train.csv": "91f8a3eb1f872f81e9c420241b6e44b1ba0c6592378708f1c947d575e28d9e8a",
    "validation.csv": "25faae1290920494fe25d0eccf2487ee9a32f48475fd0be697869b50c9371129",
    "test.csv": "dc0cfd5253ae837e447e70d2ee22645b83bee43c383384f5e1882f72f9279c4b",
    "dataset-card.md": "eb463d138e56d68404ad0fc37eca88c577c3f9ac14f58b736b5d0d0e5e5ac9c1",
    "loader.py": "6398125f652ed63f58ef4e4b91e2a0affcd572b5824eb470585f363a85ec2779",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def normalized(text):
    return " ".join(re.findall(r"\w+", unicodedata.normalize("NFKC", text).casefold()))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def main():
    for name, expected in SOURCE_HASHES.items():
        assert digest(ROOT / "source" / name) == expected, f"Source checksum mismatch: {name}"

    source = read_csv(ROOT / "source/qa.csv")
    source.sort(key=lambda r: int(r["idx"].split("_")[1]))
    source_ids = {r["idx"] for r in source}
    assert len(source) == len(source_ids) == 1195

    # PSV is intentionally plain: split at the first pipe, preserve query quotes.
    lines = (ROOT / "annotations.psv").read_text().splitlines()
    assert lines[0] == "source_id|query"
    annotations = [line.split("|", 1) for line in lines[1:]]
    queries = dict(annotations)
    assert len(annotations) == len(queries) == 1195, "Duplicate/missing annotations"
    assert set(queries) == source_ids, "Annotation IDs must exactly cover the source"
    for sid, query in annotations:
        assert query and query == query.strip(), f"Empty/untrimmed query: {sid}"
        assert len(query) <= 2048 and "\\" not in query, f"Invalid query serialization: {sid}"
        assert re.search(r"\b(?:AND|OR|W/\w+)\b", query), f"Missing connector: {sid}"

    original_split = {}
    for split in ("train", "validation", "test"):
        for row in read_csv(ROOT / f"source/{split}.csv"):
            assert row["idx"] not in original_split, "Source split overlap"
            original_split[row["idx"]] = split
    assert set(original_split) == source_ids

    # Unite known shared scenarios before assigning optional evaluation splits.
    # This is exact normalization/grouping, not semantic near-duplicate detection.
    parent = {sid: sid for sid in source_ids}

    def find(sid):
        while parent[sid] != sid:
            parent[sid] = parent[parent[sid]]
            sid = parent[sid]
        return sid

    def union(a, b):
        a, b = find(a), find(b)
        if a != b:
            parent[max(a, b)] = min(a, b)

    known = {}
    for row in source:
        keys = [("prompt_id", row["prompt_id"])]
        if normalized(row["prompt"]):
            keys.append(("prompt_text", normalized(row["prompt"])))
        full_item = [row[k] for k in ("prompt", "question", "choice_a", "choice_b", "choice_c", "choice_d")]
        keys.append(("full_item", normalized(" \n ".join(full_item))))
        for key in keys:
            if key in known:
                union(row["idx"], known[key])
            else:
                known[key] = row["idx"]

    members = defaultdict(list)
    for sid in sorted(source_ids):
        members[find(sid)].append(sid)
    group_ids, group_splits = {}, {}
    for leader, ids in members.items():
        value = hashlib.sha256("\n".join(ids).encode()).hexdigest()
        group_ids[leader] = "scenario_" + value[:12]
        bucket = int(hashlib.sha256(("stanford-bar-research-v1:" + value).encode()).hexdigest()[:16], 16) % 100
        group_splits[leader] = "train" if bucket < 80 else "validation" if bucket < 90 else "test"

    output = []
    for row in source:
        sid = row["idx"]
        flags = []
        if not row["subject"]:
            flags.append("subject_missing")
        malformed_source = len(row["source"]) > 80
        if malformed_source:
            flags.append("malformed_exam_source")
        if not row["prompt"].strip() and (
            re.match(r"(?:For this question|Assume for this question)", row["question"], re.I)
            or len(row["question"]) < 140
        ):
            flags.append("possible_missing_shared_context")
        if not row["prompt"].strip() and re.match(r"(?:In which|Which of|Which one)", row["question"]):
            flags.append("choices_needed_to_identify_issue")
        if sid == "mbe_949":
            flags.append("composite_question_text")
        if sid == "mbe_960":
            flags.append("claim_referenced_but_not_stated")
        output.append({
            "query_id": "stanford_bar_" + sid,
            "source_id": sid,
            "query": queries[sid],
            "query_language": "lexis_terms_and_connectors",
            "synthetic": True,
            "review_status": "assistant_authored_not_attorney_reviewed",
            "subject": row["subject"] or None,
            "exam_source": None if malformed_source else row["source"] or None,
            "source_split": original_split[sid],
            "scenario_group": group_ids[find(sid)],
            "recommended_split": group_splits[find(sid)],
            "source_quality_flags": flags,
            "source_prompt_id": row["prompt_id"],
            "source_question_number": row["question_number"],
            "source_prompt": row["prompt"],
            "source_question": row["question"],
            **{k: row[k] for k in ("choice_a", "choice_b", "choice_c", "choice_d")},
        })

    with (ROOT / "queries.jsonl").open("w") as f:
        for row in output:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    with (ROOT / "queries.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(output[0]))
        writer.writeheader()
        for row in output:
            writer.writerow({**row, "source_quality_flags": json.dumps(row["source_quality_flags"])})
    (ROOT / "queries.txt").write_text("".join(r["query"] + "\n" for r in output))

    group_source_splits = defaultdict(set)
    for row in output:
        group_source_splits[row["scenario_group"]].add(row["source_split"])
    repeated_queries = {q: n for q, n in Counter(queries.values()).items() if n > 1}
    assert not repeated_queries, "Exact duplicate queries require review"
    assert all(not {"answer", "gold_passage", "gold_idx"} & r.keys() for r in output)
    manifest = {
        "name": "Stanford Bar Exam Case Research Queries",
        "version": "1.0.0",
        "count": len(output),
        "source_unique_ids": len(source_ids),
        "source_unique_question_stems": len({r["question"] for r in source}),
        "source_dataset": "reglab/barexam_qa",
        "source_url": "https://huggingface.co/datasets/reglab/barexam_qa",
        "source_revision": REVISION,
        "source_scope": "All 1195 public historical MBE examples; no private BarBri data",
        "license": "CC-BY-SA-4.0",
        "synthetic": True,
        "generation": "One assistant-authored research query per source ID, using question/context and choices when necessary; answer keys and gold passages were not used to formulate queries.",
        "retrieval_validated": False,
        "attorney_reviewed": False,
        "subject_counts": dict(Counter(r["subject"] or "UNLABELED" for r in output)),
        "original_split_counts": dict(Counter(r["source_split"] for r in output)),
        "recommended_split_counts": dict(Counter(r["recommended_split"] for r in output)),
        "scenario_group_count": len(members),
        "original_groups_spanning_splits": sum(len(v) > 1 for v in group_source_splits.values()),
        "grouping": "Connected components of source prompt_id, normalized nonempty prompt, or normalized full item including choices; semantic near-duplicates may remain.",
        "quality_flag_counts": dict(Counter(flag for r in output for flag in r["source_quality_flags"])),
        "exact_duplicate_queries": len(repeated_queries),
        "source_sha256": SOURCE_HASHES,
        "annotations_sha256": digest(ROOT / "annotations.psv"),
        "output_sha256": {name: digest(ROOT / name) for name in ("queries.jsonl", "queries.csv", "queries.txt")},
    }
    write_json(ROOT / "manifest.json", manifest)
    print(json.dumps({k: manifest[k] for k in ("count", "scenario_group_count", "original_split_counts", "recommended_split_counts", "quality_flag_counts")}, indent=2))


if __name__ == "__main__":
    main()
