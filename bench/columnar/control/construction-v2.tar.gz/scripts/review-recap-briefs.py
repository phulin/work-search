#!/usr/bin/env python3
"""Print compact source excerpts for assistant review of the random PDF prefix."""

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
ROOT = PROJECT / "work/courtlistener-brief-research"
OUT = PROJECT / "data/courtlistener-brief-research"


def brief_id(filename):
    return "rb_" + hashlib.sha256(filename.encode()).hexdigest()[:12]


def case_group(record, text):
    # MDL member dockets can carry copies of the same master-case filings.
    header = re.sub(r"\s+", " ", text[:7000])
    match = re.search(r"\b(?:\d+:)?\d{2}-md-0*(\d{3,5})\b|\bMDL\s*(?:No\.?|Number)?\s*[:#.]?\s*(\d{3,5})\b", header, re.I)
    return "mdl_" + next(v for v in match.groups() if v) if match else record["item"]["identifier"]


def text_fingerprint(text):
    clean = []
    for line in text.splitlines():
        if re.search(r"(?:Document\s+\d+|Doc\s*#\s*:).*(?:Filed|Page)", line, re.I):
            continue
        line = re.sub(r"^\s*\d{1,2}\s+", "", line).strip()
        if re.fullmatch(r"(?:\d{1,4}|#:\s*\d+|PageID\.?\s*:?\s*\d+)", line, re.I):
            continue
        clean.append(line)
    return hashlib.sha256(" ".join(re.findall(r"\w+", " ".join(clean).casefold())).encode()).hexdigest()


def annotations():
    result = {}
    path = OUT / "annotations.psv"
    if path.exists():
        for line in path.read_text().splitlines()[1:]:
            sid, style, purpose, query = line.split("|", 3)
            assert sid not in result, f"Duplicate annotation: {sid}"
            result[sid] = {"style": style, "purpose": purpose, "query": query}
    return result


def rejections():
    path = OUT / "rejections.psv"
    if not path.exists():
        return {}
    return dict(line.split("|", 1) for line in path.read_text().splitlines()[1:])


def completed_prefix(available=False):
    records = []
    path = ROOT / "candidate-documents.jsonl"
    if not path.exists():
        return []
    lines = path.read_text().splitlines()
    if available:
        for extra in sorted(ROOT.glob("candidate-documents-dockets-*.jsonl")):
            lines.extend(extra.read_text().splitlines())
    for line in lines:
        item = json.loads(line)
        report = ROOT / "screening" / (item["file"]["name"] + ".json")
        if not report.exists():
            if available:
                continue
            break
        record = json.loads(report.read_text())
        record["brief_id"] = brief_id(record["file"]["name"])
        records.append(record)
    return records


def excerpt(text, length=1200):
    lines = text.splitlines()
    clean = []
    for line in lines:
        if re.search(r"(?:Document\s+\d+|Doc\s*#\s*:).*(?:Filed|Page)", line, re.I):
            continue
        line = re.sub(r"^\s*\d{1,2}\s+", "", line).strip()
        if line and not re.fullmatch(r"\d{1,3}", line):
            clean.append(line)
    joined = "\n".join(clean)
    introduction = re.search(r"(?im)^(?:[IVX]+\.\s*)?(?:INTRODUCTION(?: AND SUMMARY OF ARGUMENT)?|PRELIMINARY STATEMENT|SUMMARY OF (?:THE )?ARGUMENT)\s*[:.]?\s*$", joined)
    if introduction:
        start = introduction.end()
    else:
        argument = re.search(r"(?im)^(?:[IVX]+\.\s*)?(?:ARGUMENT(?: AND AUTHORITIES)?|BACKGROUND|STATEMENT OF (?:THE )?(?:FACTS|CASE))\s*[:.]?\s*$", joined)
        if argument:
            start = argument.end()
        else:
            opening = re.search(r"(?im)^(?=[^\n]{55,})(?=[^\n]*\b(?:respectfully|moves|submits|opposes|requests|seeks|argues|contends|pursuant|plaintiff|defendant|petitioner|respondent)\b)(?![^\n]*@)[^\n]+", joined)
            start = opening.start() if opening else 0
    body = re.sub(r"\s+", " ", joined[start:])[:length]
    headings = []
    for line in clean:
        if re.match(r"^(?:[IVX]{1,6}\.|[A-Z]\.)\s+\S", line) and 12 < len(line) < 180 and not re.search(r"\.{3,}", line):
            if line not in headings:
                headings.append(line)
    return body, headings[:8]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--count", type=int, default=15)
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--chars", type=int, default=1200)
    parser.add_argument("--max-per-docket", type=int, default=5)
    parser.add_argument("--available", action="store_true", help="Review completed download shards, including beyond the prefix")
    parser.add_argument("--compact", action="store_true")
    args = parser.parse_args()
    existing, rejected = annotations(), rejections()
    prefix = completed_prefix(args.available)
    counts = Counter()
    seen = set()
    pending = []
    # Reserve existing reviewed selections when multiple download shards advance.
    for record in prefix:
        if record["brief_id"] in existing:
            text = (ROOT / record["text_path"]).read_text(errors="replace")
            counts[case_group(record, text)] += 1
            seen.add(text_fingerprint(text))
    for record in prefix:
        if record.get("status") != "candidate_brief" or record["brief_id"] in rejected or record["brief_id"] in existing:
            continue
        if not (ROOT / record["text_path"]).is_file():
            continue  # An unselected source cache may have been pruned after export.
        text = (ROOT / record["text_path"]).read_text(errors="replace")
        fingerprint = text_fingerprint(text)
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        docket = case_group(record, text)
        if counts[docket] >= args.max_per_docket:
            continue
        counts[docket] += 1
        if record["brief_id"] not in existing:
            pending.append(record)
    print(json.dumps({"completed_pdf_prefix": len(prefix), "annotations": len(existing), "rejected": len(rejected), "pending_with_docket_cap": len(pending), "candidate_dockets": len(counts)}))
    for record in pending[args.offset : args.offset + args.count]:
        path = ROOT / record["text_path"]
        text = path.read_text(errors="replace")
        body, headings = excerpt(text, args.chars)
        if args.compact:
            print(record["brief_id"] + " | " + record["item"].get("title", "") + " | " + body + " | " + " / ".join(headings[:4]))
            continue
        print("\n" + record["brief_id"] + " | " + record["file"]["name"] + " | " + record["date_filed"] + " | " + record["item"].get("title", ""))
        print("BODY: " + body)
        print("HEADINGS: " + " / ".join(headings))


if __name__ == "__main__":
    main()
