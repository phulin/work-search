#!/usr/bin/env python3
"""Collect recent briefs from Free Law Project's public Internet Archive mirror.

Uses public item metadata and PDF downloads, not authenticated CourtListener APIs.
The sampling frame and every screening decision are retained for audit.
"""

import argparse
import concurrent.futures
import datetime as dt
import hashlib
import json
import math
import re
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "work/courtlistener-brief-research"
USER_AGENT = "work-search-public-legal-research-dataset/1.0"
LOCK = threading.Lock()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    temp.replace(path)


def fetch(url, limit=25_000_000, timeout=45):
    for attempt in range(3):
        try:
            request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(request, timeout=timeout) as response:
                body = response.read(limit + 1)
                if len(body) > limit:
                    raise ValueError("Response exceeds size limit")
                return body
        except urllib.error.HTTPError as error:
            if error.code not in (429, 500, 502, 503, 504) or attempt == 2:
                raise
            retry = error.headers.get("Retry-After", "")
            delay = int(retry) if retry.isdigit() else 2 ** (attempt + 1)
            if delay > 60:
                raise RuntimeError(f"Server requested {delay}s backoff; resume later") from error
            time.sleep(delay)
        except (TimeoutError, urllib.error.URLError):
            if attempt == 2:
                raise
            time.sleep(2 ** (attempt + 1))


def create_frame(args):
    """Enumerate metadata in bounded date partitions, never relevance-top-N."""
    directory = ROOT / "frame-search"
    directory.mkdir(parents=True, exist_ok=True)

    def partition(start, end):
        path = directory / f"{start}_{end}.json"
        query = (
            "collection:usfederalcourts AND files_count:[5 TO *] AND "
            f"indexdate:[{start}T00:00:00Z TO {end}T23:59:59Z]"
        )
        if path.exists():
            result = json.loads(path.read_text())
        else:
            params = {"q": query, "fl[]": ["identifier", "title", "court", "indexdate", "publicdate", "files_count", "item_size"], "rows": 10000, "output": "json", "sort[]": "identifier asc"}
            url = "https://archive.org/advancedsearch.php?" + urllib.parse.urlencode(params, doseq=True)
            result = json.loads(fetch(url, 30_000_000))
            dump(path, result)
        response = result["response"]
        count = response["numFound"]
        if count > 10000:
            if start == end:
                raise RuntimeError(f"More than 10000 items on {start}; refine partition")
            middle = start + (end - start) // 2
            return partition(start, middle) + partition(middle + dt.timedelta(days=1), end)
        assert len(response["docs"]) == count, "Incomplete metadata frame partition"
        print(json.dumps({"frame_partition": str(start) + "/" + str(end), "items": count}), flush=True)
        return response["docs"]

    start, end = dt.date.fromisoformat(args.start), dt.date.fromisoformat(args.end)
    parts = []
    cursor = start
    while cursor <= end:
        finish = min(end, cursor + dt.timedelta(days=6))
        parts.append((cursor, finish))
        cursor = finish + dt.timedelta(days=1)
    rows = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(args.workers, 8)) as pool:
        for result in pool.map(lambda pair: partition(*pair), parts):
            for item in result:
                if re.fullmatch(r"gov\.uscourts\.[a-z0-9]+\.[a-zA-Z0-9.-]+", item["identifier"]):
                    rows[item["identifier"]] = item
    ordered = sorted(rows.values(), key=lambda item: item["identifier"])
    (ROOT / "mirror-frame.jsonl").write_text("".join(json.dumps(row) + "\n" for row in ordered))
    dump(ROOT / "frame-manifest.json", {
        "start": args.start, "end": args.end, "count": len(ordered), "seed": args.seed,
        "frame": "Public usfederalcourts mirror items indexed within the date window, with at least 5 archived files; non-PDF metadata files count toward that threshold.",
        "sampling": "Weighted random order without replacement over docket items; weight=max(1,files_count-4), an approximate archived-document count. This is a mirror-based two-stage sample, not a uniform sample of all U.S. filings.",
        "filing_recency": "Index/upload dates only identify candidates. PDF filing headers must independently establish actual filing dates within the requested window.",
    })
    print(json.dumps({"complete_frame_items": len(ordered)}), flush=True)


def docket_rank(row, seed):
    hashed = hashlib.sha256(f"{seed}:{row['identifier']}".encode()).digest()
    uniform = (int.from_bytes(hashed[:8], "big") + 1) / (2 ** 64 + 1)
    weight = max(1, int(row.get("files_count", 5)) - 4)
    return -math.log(uniform) / weight


def filing_date(text):
    # Use the first filing header; attached exhibits can carry older headers.
    match = re.search(r"\b(?:Date\s+)?Filed\s*:?\s*(\d{1,2}/\d{1,2}/\d{2,4})\b", text[:5000], re.I)
    if not match:
        return None, None
    date = match.group(1)
    try:
        value = dt.datetime.strptime(date, "%m/%d/%Y" if len(date.rsplit("/", 1)[1]) == 4 else "%m/%d/%y").date()
        return value.isoformat(), match.group(0)
    except ValueError:
        return None, match.group(0)


def screen(text, start, end):
    date, evidence = filing_date(text)
    if date is None:
        return "no_parseable_filing_header", date, evidence
    if not start <= date <= end:
        return "filing_outside_window", date, evidence
    # Strip line-number margins and filing headers before title screening.
    pages = text.split("\f")
    first = "\n".join(pages[:2])
    first = re.sub(r"(?m)^\s*\d{1,2}\s+", "", first)
    first = re.sub(r"(?im)^.*(?:Document\s+\d+|Doc\s*#\s*:).*(?:Filed|Page).*$", "", first)
    head = re.sub(r"\s+", " ", first[:6500]).upper()
    positive = r"\bBRIEF\b|MEMORANDUM\s+(?:OF\s+(?:LAW|POINTS)|IN\s+(?:SUPPORT|OPPOSITION))|\b(?:REPLY|RESPONSE)\s+(?:BRIEF|MEMORANDUM|IN\s+(?:SUPPORT|OPPOSITION))|\bOPPOSITION\s+TO\b"
    match = re.search(positive, head[:4500])
    judicial = r"MEMORANDUM\s+(?:OPINION|DECISION|AND\s+(?:OPINION|ORDER))|(?:OPINION|DECISION)\s+(?:AND|&)\s+ORDER|REPORT\s+AND\s+RECOMMENDATION|ORDER\s+(?:GRANTING|DENYING|DISMISSING|ADOPTING)"
    negative = re.search(judicial, head[:2500])
    if negative and (not match or negative.start() < match.start()):
        return "judicial_opinion_or_order", date, evidence
    nonbrief = re.search(r"CIVIL\s+(?:STANDARD\s+)?MINUTES|JOINT\s+STATUS\s+REPORT|PLEASE\s+TAKE\s+NOTICE|DECLARATION\s+(?:OF|IN)|AFFIDAVIT\s+OF|CERTIFICATE\s+OF\s+SERVICE|NOTICE\s+OF\s+(?:MOTION|FILING|APPEARANCE|SUPPLEMENTAL|WITHDRAWAL)", head[:3500])
    if nonbrief and (not match or nonbrief.start() < match.start()):
        return "notice_declaration_or_administrative_filing", date, evidence
    if not match:
        return "not_identified_as_brief", date, evidence
    if len(text) < 3500:
        return "insufficient_substantive_text", date, evidence
    # A mention of a prior brief inside an order is insufficient. Retain the
    # heuristic evidence for later assistant review of actual document titles.
    return "candidate_brief", date, evidence


def collect(args):
    rows = [json.loads(line) for line in (ROOT / "mirror-frame.jsonl").read_text().splitlines()]
    rows.sort(key=lambda row: docket_rank(row, args.seed))
    rows = rows[args.docket_start:args.dockets]
    paths = {name: ROOT / name for name in ("ia-metadata", "pdfs", "text", "screening")}
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    minimum_upload = dt.datetime.fromisoformat(args.start).replace(tzinfo=dt.timezone.utc).timestamp()
    documents = []

    def metadata(row):
        item = row["identifier"]
        path = paths["ia-metadata"] / (item + ".json")
        try:
            if path.exists():
                data = json.loads(path.read_text())
            else:
                data = json.loads(fetch("https://archive.org/metadata/" + item))
                dump(path, data)
            files = []
            for entry in data.get("files", []):
                if not entry["name"].endswith(".pdf"):
                    continue
                if float(entry.get("mtime", 0)) < minimum_upload:
                    continue
                if not 15000 <= int(entry.get("size", 0)) <= args.max_pdf_bytes:
                    continue
                files.append({"item": row, "file": entry, "metadata_source_url": data.get("metadata", {}).get("source_url"), "archive_storage_base": "https://" + data["d1"] + data["dir"] if data.get("d1") and data.get("dir") else None})
            files.sort(key=lambda value: hashlib.sha256(f"{args.seed}:{value['file']['name']}".encode()).hexdigest())
            return files[:args.max_files_per_docket]
        except Exception as error:
            dump(ROOT / "errors" / (item + ".json"), {"item": item, "stage": "metadata", "error": str(error)})
            return []

    with concurrent.futures.ThreadPoolExecutor(max_workers=min(args.workers, 8)) as pool:
        for index, files in enumerate(pool.map(metadata, rows), 1):
            documents.extend(files)
            if index % 50 == 0:
                print(json.dumps({"metadata_dockets": index, "candidate_pdfs": len(documents)}), flush=True)
    documents.sort(key=lambda doc: hashlib.sha256(f"{args.seed}:{doc['file']['name']}".encode()).hexdigest())
    cohort = f"-dockets-{args.docket_start}-{args.dockets}" if args.docket_start else ""
    if not args.offset:
        (ROOT / f"candidate-documents{cohort}.jsonl").write_text("".join(json.dumps(doc) + "\n" for doc in documents))
    documents = documents[args.offset:]
    print(json.dumps({"dockets_screened": len(rows), "pdf_candidates": len(documents)}), flush=True)

    def document(value):
        item, file = value["item"], value["file"]
        name = file["name"]
        report_path = paths["screening"] / (name + ".json")
        if report_path.exists() and not (args.redownload_missing and not (paths["pdfs"] / name).is_file()):
            record = json.loads(report_path.read_text())
            text_path = ROOT / record.get("text_path", "nonexistent")
            if record.get("screen_version") != 2 and text_path.is_file():
                text = text_path.read_text(errors="replace")
                status, date, evidence = screen(text, args.start, args.end)
                record.update({"status": status, "date_filed": date, "date_evidence": evidence, "screen_version": 2})
                dump(report_path, record)
            return record
        url = "https://archive.org/download/" + item["identifier"] + "/" + urllib.parse.quote(name)
        record = {**value, "download_url": url, "courtlistener_pdf_url": "https://storage.courtlistener.com/recap/" + item["identifier"] + "/" + name}
        try:
            pdf = paths["pdfs"] / name
            text_path = paths["text"] / (name + ".txt")
            if not pdf.exists():
                # Use the archival mirror to avoid loading the live legal
                # research service. Preserve the original URL as provenance.
                try:
                    direct = value.get("archive_storage_base")
                    download = direct + "/" + urllib.parse.quote(name) if direct else url
                    body = fetch(download, args.max_pdf_bytes, timeout=20)
                    record["downloaded_from"] = download
                except (urllib.error.URLError, urllib.error.HTTPError):
                    raise
                if not body.startswith(b"%PDF"):
                    raise ValueError("Download is not a PDF")
                if file.get("sha1") and hashlib.sha1(body).hexdigest() != file["sha1"]:
                    raise ValueError("Internet Archive SHA-1 mismatch")
                pdf.write_bytes(body)
            if not text_path.exists():
                subprocess.run(["pdftotext", "-layout", str(pdf), str(text_path)], check=True, capture_output=True, timeout=45)
            text = text_path.read_text(errors="replace")
            status, date, evidence = screen(text, args.start, args.end)
            record.update({"status": status, "screen_version": 2, "date_filed": date, "date_evidence": evidence, "text_characters": len(text), "pdf_sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(), "pdf_path": str(pdf.relative_to(ROOT)), "text_path": str(text_path.relative_to(ROOT))})
        except Exception as error:
            record.update({"status": "download_or_extraction_error", "error": str(error)})
        dump(report_path, record)
        return record

    results = []
    counts = Counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for offset in range(0, len(documents), args.workers * 8):
            batch = documents[offset : offset + args.workers * 8]
            for record in pool.map(document, batch):
                results.append(record)
                counts[record["status"]] += 1
            print(json.dumps({"pdfs_screened": len(results), "statuses": dict(counts)}), flush=True)
            if args.candidate_target and counts["candidate_brief"] >= args.candidate_target:
                break
    suffix = cohort + (f"-offset-{args.offset}" if args.offset else "")
    (ROOT / f"screened-documents{suffix}.jsonl").write_text("".join(json.dumps(row) + "\n" for row in results))
    candidates = [row for row in results if row["status"] == "candidate_brief"]
    (ROOT / f"candidate-briefs{suffix}.jsonl").write_text("".join(json.dumps(row) + "\n" for row in candidates))
    dump(ROOT / f"collection-summary{suffix}.json", {"start": args.start, "end": args.end, "seed": args.seed, "dockets": len(rows), "offset": args.offset, "max_files_per_docket": args.max_files_per_docket, "candidate_pdfs": len(documents), "pdfs_screened": len(results), "candidate_target": args.candidate_target, "statuses": dict(counts), "candidate_briefs": len(candidates)})
    print(json.dumps({"complete": True, "statuses": dict(counts), "candidate_briefs": len(candidates)}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("frame", "collect"))
    parser.add_argument("--start", default="2026-08-15")
    parser.add_argument("--end", default="2026-11-12")
    parser.add_argument("--seed", default="20261113")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--dockets", type=int, default=100)
    parser.add_argument("--max-pdf-bytes", type=int, default=10_000_000)
    parser.add_argument("--max-files-per-docket", type=int, default=20)
    parser.add_argument("--candidate-target", type=int, default=0)
    parser.add_argument("--offset", type=int, default=0, help="Start a disjoint download shard at this PDF index")
    parser.add_argument("--docket-start", type=int, default=0, help="Start a disjoint cohort at this seeded docket rank")
    parser.add_argument("--redownload-missing", action="store_true", help="Recreate pruned PDF/text caches even when screening reports exist")
    args = parser.parse_args()
    assert 1 <= args.workers <= 32
    ROOT.mkdir(parents=True, exist_ok=True)
    if args.stage == "frame":
        create_frame(args)
    else:
        collect(args)


if __name__ == "__main__":
    main()
