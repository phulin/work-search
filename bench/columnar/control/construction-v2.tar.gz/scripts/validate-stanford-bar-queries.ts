import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { parse, queryTerms } from "../src/query/parser.js";

const root = fileURLToPath(
  new URL("../data/stanford-bar-research/", import.meta.url),
);
const rows = readFileSync(root + "queries.jsonl", "utf8")
  .trim()
  .split("\n")
  .map((line) => JSON.parse(line));
const failures: { source_id: string; error: string }[] = [];
const termCounts: number[] = [];
for (const row of rows) {
  try {
    const ast = parse(row.query);
    if (ast.kind === "empty") throw new Error("Empty query");
    termCounts.push(queryTerms(ast).length);
  } catch (error) {
    failures.push({ source_id: row.source_id, error: String(error) });
  }
}
const report = {
  count: rows.length,
  unique_source_ids: new Set(rows.map((r) => r.source_id)).size,
  unique_queries: new Set(rows.map((r) => r.query)).size,
  parser: "src/query/parser.ts",
  parser_validation:
    "Local syntax/complexity check; not Lexis execution or retrieval validation",
  parsed_successfully: termCounts.length,
  max_distinct_terms: Math.max(...termCounts),
  max_query_characters: Math.max(...rows.map((r) => r.query.length)),
  failures,
};
writeFileSync(root + "validation.json", JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify(report, null, 2));
if (
  failures.length ||
  rows.length !== 1195 ||
  report.unique_source_ids !== 1195
) {
  process.exitCode = 1;
}
