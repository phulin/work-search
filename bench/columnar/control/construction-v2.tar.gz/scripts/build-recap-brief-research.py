#!/usr/bin/env python3
"""Export source-grounded brief/query pairs and validate their local provenance."""

import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
import re
import tarfile
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("review", HERE / "review-recap-briefs.py")
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
ROOT, OUT = review.ROOT, review.OUT
STYLES = {"nl": "natural_language", "kw": "keywords", "bool": "boolean", "prox": "proximity", "cite": "citation_lookup"}
PURPOSES = {"facts": "factual_analogy", "standard": "legal_standard", "procedure": "procedure", "statute": "statutory_interpretation", "authority": "known_authority", "contrary": "contrary_authority"}


def sha(path):
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def build(count, archive):
    annotations = review.annotations()
    assert len(annotations) == count, f"Expected {count} annotations; have {len(annotations)}"
    filter_path = OUT / "selection-filter.json"
    selection_filter = json.loads(filter_path.read_text()) if filter_path.exists() else None
    if selection_filter:
        assert count == selection_filter["retained_rows"]
        assert all(a["style"] in selection_filter["kept_annotation_styles"] for a in annotations.values())
    assert not set(annotations) & set(review.rejections())
    source = {r["brief_id"]: r for r in review.completed_prefix(available=True)}
    groups, courts, dates, fingerprints = Counter(), Counter(), Counter(), set()
    hashes, filenames, rows, texts, records = set(), set(), [], [], []
    for bid, annotation in annotations.items():
        record = source[bid]
        assert record["status"] in {"candidate_brief", "notice_declaration_or_administrative_filing"}, bid
        assert "2026-08-15" <= record["date_filed"] <= "2026-11-12", bid
        pdf, txt = ROOT / record["pdf_path"], ROOT / record["text_path"]
        assert pdf.is_file() and txt.is_file(), bid
        digest = sha(pdf)
        assert digest == record["pdf_sha256"], bid
        assert digest not in hashes, f"Duplicate PDF: {bid}"
        hashes.add(digest)
        text = txt.read_text(errors="replace")
        fingerprint = review.text_fingerprint(text)
        assert fingerprint not in fingerprints, f"Duplicate normalized text: {bid}"
        fingerprints.add(fingerprint)
        group = review.case_group(record, text)
        groups[group] += 1
        assert groups[group] <= 5, f"Case family cap exceeded: {group}"
        filename = record["file"]["name"]
        assert filename not in filenames
        filenames.add(filename)
        court = record["item"]["identifier"].split(".")[2]
        courts[court] += 1
        dates[record["date_filed"][:7]] += 1
        body, headings = review.excerpt(text, 1400)
        query = annotation["query"]
        assert 0 < len(query) <= 2048 and "\n" not in query
        row = {
            "brief_id": bid, "query": query, "query_style": STYLES[annotation["style"]],
            "research_purpose": PURPOSES[annotation["purpose"]],
            "synthetic_query": True, "query_origin": "assistant_inferred_from_brief",
            "automatic_screening_status": record["status"],
            "assistant_review_overrode_screen": record["status"] != "candidate_brief",
            "archive_case_title": record["item"].get("title", ""), "court_id": court,
            "case_family": group, "date_filed": record["date_filed"],
            "filing_date_evidence": record["date_evidence"],
            "source_filename": filename, "courtlistener_pdf_url": record["courtlistener_pdf_url"],
            "archive_pdf_url": record["download_url"],
            "archive_item_url": "https://archive.org/details/" + record["item"]["identifier"],
            "pdf_sha256": digest, "pdf_bytes": pdf.stat().st_size,
            "pdf_local_path": str(pdf), "text_local_path": str(txt),
            "source_excerpt": body, "source_headings": " / ".join(headings),
        }
        rows.append(row)
        texts.append({"brief_id": bid, "source_filename": filename, "text": text})
        records.append(record)
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "queries.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (OUT / "queries.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows))
    (OUT / "queries.txt").write_text("".join(r["query"] + "\n" for r in rows))
    with gzip.open(OUT / "brief-texts.jsonl.gz", "wt", encoding="utf-8") as handle:
        for row in texts:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    (OUT / "source-records.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in records))
    word_counts = sorted(len(re.findall(r"\S+", r["query"])) for r in rows)
    styles = Counter(r["query_style"] for r in rows)
    purposes = Counter(r["research_purpose"] for r in rows)
    duplicates = {q: n for q, n in Counter(r["query"] for r in rows).items() if n > 1}
    distribution = {
        "rows": len(rows), "unique_queries": len(set(r["query"] for r in rows)),
        "query_styles": dict(styles), "research_purposes": dict(purposes),
        "court_ids": dict(courts.most_common()), "filing_months": dict(sorted(dates.items())),
        "case_families": len(groups), "max_briefs_per_case_family": max(groups.values()),
        "query_words": {"min": min(word_counts), "median": word_counts[len(word_counts)//2], "max": max(word_counts)},
        "repeated_queries": duplicates,
    }
    write_json(OUT / "distribution.json", distribution)
    write_json(OUT / "validation.json", {"expected_rows": count, "rows": len(rows), "unique_pdf_sha256": len(hashes), "unique_normalized_texts": len(fingerprints), "all_source_files_present": True, "all_pdf_checksums_match": True, "all_filing_dates_in_window": True, "max_case_family_count": max(groups.values()), "attorney_reviewed": False, "retrieval_validated": False})
    frame = json.loads((ROOT / "frame-manifest.json").read_text())
    frame["mirror_frame_sha256"] = sha(ROOT / "mirror-frame.jsonl")
    frame["candidate_pools"] = {p.name: sha(p) for p in sorted(ROOT.glob("candidate-documents*.jsonl"))}
    identifiers = set()
    for path in ROOT.glob("candidate-documents*.jsonl"):
        identifiers.update(json.loads(line)["item"]["identifier"] for line in path.read_text().splitlines())
    frame["dockets_with_candidate_pdfs"] = len(identifiers)
    frame["max_candidate_pdfs_per_docket"] = 20
    collection_audit = ROOT / "collection-audit.json"
    if collection_audit.exists():
        frame["collection_audit"] = json.loads(collection_audit.read_text())
    frame["exported_rows"] = count
    if selection_filter:
        frame["selection_filter"] = selection_filter
    frame["selected_pdf_bytes"] = sum(r["pdf_bytes"] for r in rows)
    frame["selection"] = "Seeded random candidate pool; assistant-reviewed substantive briefs; existing reviewed pilot selections retained as download shards completed; exact and normalized-text duplicates removed; at most five briefs per docket or identified MDL family. This is a curated random-pool sample, not a simple random sample of all briefs."
    frame["query_generation"] = "One assistant-inferred search per brief, based on extracted introductory text and argument headings; ambiguous records inspected further. Styles and purposes assigned as workload design choices, not estimated usage frequencies."
    frame["source_limitations"] = ["Federal public RECAP mirror coverage only; not representative of all US court filings.", "Archive case titles are preserved metadata and are not independently verified case captions.", "Only extractable PDFs with parseable filing headers; excludes scanned text that could not be extracted.", "Candidate PDFs limited to 15 KB–10 MB and at most 20 randomly ordered candidates per sampled docket.", "Completed briefs reveal final arguments and citations, creating hindsight leakage for query inference.", "Queries are synthetic; no actual attorney search logs, attorney review, Lexis execution, or relevance judgments."]
    write_json(OUT / "manifest.json", frame)
    if archive:
        destination = ROOT / "deliverables" / "briefs.tar.gz"
        destination.parent.mkdir(exist_ok=True)
        with tarfile.open(destination, "w:gz", compresslevel=1) as bundle:
            for record in records:
                bundle.add(ROOT / record["pdf_path"], arcname="briefs/" + record["file"]["name"])
        assert len(tarfile.open(destination).getmembers()) == count
        write_json(OUT / "brief-archive.json", {"path": str(destination), "briefs": count, "bytes": destination.stat().st_size, "sha256": sha(destination)})
    # Verify both structured exports survive their respective serialization.
    with (OUT / "queries.csv").open() as handle:
        csv_rows = list(csv.DictReader(handle))
    json_rows = [json.loads(line) for line in (OUT / "queries.jsonl").read_text().splitlines()]
    assert len(csv_rows) == len(json_rows) == count
    assert [r["query"] for r in csv_rows] == [r["query"] for r in json_rows]
    print(json.dumps(distribution, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--count", type=int, help="Expected rows; defaults to the current annotation count")
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()
    build(args.count if args.count is not None else len(review.annotations()), args.archive)
