#!/usr/bin/env python3
"""Flag possible judicial documents and similar source texts for assistant review.

This is a heuristic audit, not a proof that every near duplicate has been found.
See source-review.json for review decisions on the frozen dataset.
"""
from pathlib import Path
import json,re,heapq,zlib,itertools,collections
out=Path(__file__).resolve().parents[1]/'data/courtlistener-brief-research'
rows=[json.loads(l) for l in (out/'queries.jsonl').read_text().splitlines()]
sets=[];inverted=collections.defaultdict(list);flags=[]
for i,r in enumerate(rows):
 t=Path(r['text_local_path']).read_text(); front=t.split('\f')[0]
 clean=re.sub(r'\s+',' ',front)
 judicial=bool(re.search(r'(?i)(?:MEMORANDUM OPINION|REPORT AND RECOMMENDATION|OPINION AND ORDER|ORDER (?:GRANTING|DENYING|ON |RE:|SETTING)|IT IS (?:HEREBY )?(?:ORDERED|SO ORDERED)|THE COURT (?:HEREBY )?(?:ORDERS|GRANTS|DENIES)|THIS MATTER IS BEFORE THE COURT)',clean))
 if judicial: flags.append({'brief_id':r['brief_id'],'front':clean[:3000]})
 # Compare operative brief text, keeping first 15k words so huge appended exhibits do not dominate.
 words=re.findall(r'\w+',t.casefold())[:15000]
 s={zlib.crc32(' '.join(words[j:j+5]).encode()) for j in range(len(words)-4)}
 sets.append(s)
 for h in heapq.nsmallest(128,s):inverted[h].append(i)
counts=collections.Counter()
for indices in inverted.values():
 if len(indices)<20: counts.update(itertools.combinations(indices,2))
pairs=[]
for (i,j),n in counts.items():
 if n<35:continue
 a,b=sets[i],sets[j];inter=len(a&b);jac=inter/len(a|b);contain=inter/min(len(a),len(b))
 if jac>.7 or contain>.9:pairs.append({'a':rows[i]['brief_id'],'b':rows[j]['brief_id'],'jaccard':round(jac,3),'containment':round(contain,3),'shared_sketch':n})
(out/'source-audit.json').write_text(json.dumps({'judicial_front_page_flags':flags,'near_duplicate_pairs':pairs},indent=2))
print('Flags',len(flags),'Near duplicates',len(pairs))
for f in flags:print(f['brief_id'],f['front'][:1600])
print(json.dumps(pairs,indent=2))
