import {
  readFile,
  writeFile,
  mkdir,
  cp,
  readdir,
  rm,
  appendFile,
} from "node:fs/promises";
import { resolve } from "node:path";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import type { Root, PairRoot } from "../src/columnar/format.js";
import { benchmarkToken } from "../bench/columnar/token.js";
import { gzip } from "node:zlib";
import { promisify } from "node:util";
import { request as httpsRequest, Agent } from "node:https";
import { DocumentDirectory } from "../src/columnar/document-directory.js";
import { inspectObjects, publishAuxiliary } from "./columnar-publication.js";
import {
  loadServingAssets,
  servingOptions,
  servingImports,
  servingArguments,
  copyServingExtras,
  prepareServing,
  servingRoot,
  verifyDocumentPublication,
  bundleServing,
  matchesServingHealth,
} from "./columnar-serving.js";
const uploadConcurrency = Number(process.env.CWS_UPLOAD_CONCURRENCY ?? 8);
if (
  !Number.isInteger(uploadConcurrency) ||
  uploadConcurrency < 1 ||
  uploadConcurrency > 16
)
  throw Error("Upload concurrency must be 1..16");
const uploadAgent = new Agent({
  keepAlive: true,
  maxSockets: uploadConcurrency,
});
const compress = promisify(gzip);
let publicationHeads: Awaited<ReturnType<typeof inspectObjects>> | undefined;
function headObjectOnce(address: string, token: string) {
  return new Promise<{
    status: number;
    headers: Record<string, string | string[] | undefined>;
  }>((ok, no) => {
    const r = httpsRequest(
      address,
      {
        method: "HEAD",
        agent: uploadAgent,
        headers: { authorization: `Bearer ${token}` },
      },
      (response) => {
        response.resume();
        response.once("end", () =>
          ok({ status: response.statusCode ?? 0, headers: response.headers }),
        );
      },
    );
    r.setTimeout(120000, () => r.destroy(Error("Upload HEAD timeout")));
    r.once("error", no);
    r.end();
  });
}
async function headObject(address: string, token: string) {
  const cached = publicationHeads?.get(new URL(address).pathname.slice(1));
  if (cached?.status === 200) return cached;
  for (let attempt = 0; ; attempt++)
    try {
      return await headObjectOnce(address, token);
    } catch (e) {
      if (attempt === 4) throw e;
      await new Promise((r) => setTimeout(r, 500 * 2 ** attempt));
    }
}
function uploadObject(
  address: string,
  headers: Record<string, string>,
  body: Buffer,
) {
  // Node 26 fetch negotiates HTTP/2. Long concurrent immutable transfers hit
  // transient stream resets; use the same bounded HTTP/1 agent as HEAD checks.
  return new Promise<{ status: number; text: string }>((ok, no) => {
    const r = httpsRequest(
      address,
      { method: "PUT", agent: uploadAgent, headers },
      (response) => {
        let text = "";
        response.on("data", (chunk) => {
          if (text.length < 2000) text += chunk.toString();
        });
        response.once("error", no);
        response.once("end", () =>
          ok({ status: response.statusCode ?? 0, text }),
        );
      },
    );
    r.setTimeout(180000, () => r.destroy(Error("Immutable upload timeout")));
    r.once("error", no);
    r.end(body);
  });
}
const [out, name] = process.argv.slice(2);
if (!out || !/^[a-z0-9-]{1,48}$/.test(name ?? ""))
  throw Error(
    "Usage: yarn node --import tsx scripts/deploy-columnar.ts INDEX_DIR BENCHMARK_WORKER",
  );
if (!name.startsWith("work-search-cws-"))
  throw Error("Benchmark Worker name must begin work-search-cws-");
if (process.argv.includes("--prepare-only")) {
  console.log(
    JSON.stringify(
      await prepareServing(
        resolve(out),
        resolve(`work/columnar-deploy/${name}-prepared`),
        name,
        servingOptions(),
      ),
      null,
      2,
    ),
  );
  process.exit(0);
}
// Finish and size-check the actual Worker before credentials or remote writes.
const prepared = resolve(`work/columnar-deploy/${name}-prepared`);
await prepareServing(resolve(out), prepared, name, servingOptions());
await bundleServing(prepared);
const serving = await loadServingAssets(out, servingOptions());
const probeAt = process.argv.indexOf("--first-search"),
  probeContract =
    probeAt === -1
      ? undefined
      : JSON.parse(await readFile(process.argv[probeAt + 1], "utf8"));
if (
  probeAt !== -1 &&
  (typeof probeContract.q !== "string" ||
    !Array.isArray(probeContract.oracle) ||
    probeContract.options?.after)
)
  throw Error(
    "First-search probe requires a complete non-pagination oracle contract",
  );
const root: Root = JSON.parse(await readFile(out + "/root.json", "utf8")),
  token = await benchmarkToken();
const pairs: PairRoot | undefined = await readFile(
  out + "/pairs-root.json",
  "utf8",
).then(JSON.parse, () => undefined);
const heads = await readFile(out + "/heads-root.json", "utf8").then(
  JSON.parse,
  () => undefined,
);
if (heads && heads.baseGeneration !== root.generation)
  throw Error("Head generation mismatch");
if (pairs && pairs.baseGeneration !== root.generation)
  throw Error("Pair generation mismatch");
await mkdir("work/columnar-deploy", { recursive: true });
const sourceDir = resolve(`work/columnar-deploy/${name}-source`);
await rm(sourceDir, { recursive: true, force: true });
await mkdir(sourceDir, { recursive: true });
for (const dir of ["columnar", "query", "format", "storage"])
  await cp(`src/${dir}`, `${sourceDir}/src/${dir}`, { recursive: true });
await copyServingExtras(serving, sourceDir);
await writeFile(sourceDir + "/root.json", JSON.stringify(servingRoot(root)));
if (root.directory) {
  const data = await readFile(out + "/directory.bin");
  if (
    data.length !== root.directory.bytes ||
    createHash("sha256").update(data).digest("hex") !== root.directory.sha256
  )
    throw Error("Bundled directory identity mismatch");
  await writeFile(sourceDir + "/directory.bin", data);
}
if (root.documentPackages?.locators) {
  const data = await readFile(out + "/documents.bin"),
    d = root.documentPackages.locators;
  if (
    data.length !== d.bytes ||
    createHash("sha256").update(data).digest("hex") !== d.sha256
  )
    throw Error("Bundled document directory identity mismatch");
  await writeFile(sourceDir + "/documents.bin", data);
}
if (pairs)
  await writeFile(sourceDir + "/pairs-root.json", JSON.stringify(pairs));
if (heads) {
  await cp(out + "/heads.bin", sourceDir + "/heads.bin");
  await writeFile(sourceDir + "/heads-root.json", JSON.stringify(heads));
}
const uploaderConfig = resolve("work/columnar-deploy/upload.json");
if (!process.argv.includes("--deploy-only")) {
  await writeFile(
    uploaderConfig,
    JSON.stringify(
      {
        name: "work-search-cws-upload",
        main: resolve("src/columnar/upload-worker.ts"),
        compatibility_date: "2026-11-01",
        account_id: "8f088d4bd190caf693cc42bb8311fd7d",
        workers_dev: true,
        r2_buckets: [{ binding: "INDEX", bucket_name: "work-search-demo" }],
        limits: { cpu_ms: 300000 },
      },
      null,
      2,
    ),
  );
  await wrangler(["deploy", "--config", uploaderConfig]);
  await wrangler(
    ["secret", "put", "UPLOAD_TOKEN", "--config", uploaderConfig],
    token,
  );
}
const url = "https://work-search-cws-upload.phulin.workers.dev";
publicationHeads = await inspectObjects(url, token, [
  ...new Set([
    ...root.objects.map((o) => o.key ?? `${root.generation}/${o.name}`),
    ...(pairs?.objects ?? []).map(
      (o) => o.key ?? `${pairs!.generation}/${o.name}`,
    ),
    ...(serving.documents
      ? [...new DocumentDirectory(serving.documents).groups()].map((g) => g.key)
      : []),
  ]),
]);
if (process.argv.includes("--deploy-only")) {
  // Native publication already verifies every immutable object and full document
  // coverage before writing this exact root. Reuse that proof instead of making
  // thousands of redundant client HEAD requests on every serving deployment.
  const published = await fetch(`${url}/${root.generation}/root.json`, {
    headers: { authorization: `Bearer ${token}` },
  });
  const rootVerified =
    published.ok && (await published.text()) === JSON.stringify(root);
  const groups = [
    [root.generation, rootVerified ? [] : root.objects],
    ...(pairs ? [[pairs.generation, pairs.objects] as const] : []),
  ] as const;
  const pending = groups.flatMap(([generation, objects]) =>
    objects.map((object) => ({ generation, object })),
  );
  let next = 0;
  await Promise.all(
    Array.from({ length: uploadConcurrency }, async () => {
      for (;;) {
        const item = pending[next++];
        if (!item) return;
        const { generation, object } = item;
        const h = await headObject(
          `${url}/${object.key ?? `${generation}/${object.name}`}`,
          token,
        );
        if (
          h.status !== 200 ||
          Number(h.headers["content-length"]) !== object.size ||
          h.headers["x-sha256"] !== object.sha256
        )
          throw Error("Unpublished immutable object " + object.name);
      }
    }),
  );
}
if (!process.argv.includes("--deploy-only")) {
  const objects = [
    ...root.objects.map((object) => ({
      object,
      generation: root.generation,
      path: out + "/packs/" + object.name,
    })),
    ...(pairs?.objects ?? []).map((object) => ({
      object,
      generation: pairs!.generation,
      path: out + "/pairs/packs/" + object.name,
    })),
  ];
  let next = 0;
  await Promise.all(
    Array.from({ length: uploadConcurrency }, async () => {
      for (;;) {
        const entry = objects[next++];
        if (!entry) break;
        const { object, path, generation } = entry;
        for (let attempt = 0; ; attempt++) {
          try {
            const address = `${url}/${object.key ?? `${generation}/${object.name}`}`,
              head = await headObject(address, token);
            if (head.status === 200) {
              if (
                Number(head.headers["content-length"]) !== object.size ||
                head.headers["x-sha256"] !== object.sha256
              )
                throw Error("Immutable upload mismatch");
              break;
            }
            if (head.status !== 404) throw Error("Upload HEAD " + head.status);
            const hash = createHash("sha256");
            for await (const data of createReadStream(path)) hash.update(data);
            if (hash.digest("hex") !== object.sha256)
              throw Error("Immutable object mismatch");
            const compressed = await compress(await readFile(path), {
              level: 1,
            });
            const r = await uploadObject(
              address,
              {
                authorization: `Bearer ${token}`,
                "content-length": String(compressed.length),
                "x-sha256": object.sha256,
                "x-raw-length": String(object.size),
                ...(object.checksums
                  ? {
                      "x-page-crc32": Buffer.from(
                        Uint32Array.from(object.checksums).buffer,
                      ).toString("base64"),
                    }
                  : {}),
              },
              compressed,
            );
            if (r.status < 200 || r.status >= 300)
              throw Error("Upload " + r.status + ": " + r.text);
            break;
          } catch (e) {
            if (attempt === 4) throw e;
            await new Promise((r) => setTimeout(r, 500 * 2 ** attempt));
          }
        }
        if (process.env.CWS_RECLAIM_LOCAL === "1") {
          const verified = await headObject(
            `${url}/${object.key ?? `${generation}/${object.name}`}`,
            token,
          );
          if (
            verified.status !== 200 ||
            Number(verified.headers["content-length"]) !== object.size ||
            verified.headers["x-sha256"] !== object.sha256
          )
            throw Error("Cannot reclaim unverified object " + object.name);
          await appendFile(
            out + "/reclaimed-objects.jsonl",
            JSON.stringify({
              generation,
              name: object.name,
              key: object.key,
              sha256: object.sha256,
              size: object.size,
              at: new Date().toISOString(),
            }) + "\n",
          );
          await rm(path, { force: true });
        }
        console.log(
          "Uploaded",
          object.name,
          object.size,
          new Date().toISOString(),
        );
      }
    }),
  );
}
// Complete pair packets, common-word lists and metadata columns are separate
// immutable objects. They are required by the generated serving entry, too.
await verifyDocumentPublication(
  serving.documents,
  (key) => headObject(`${url}/${key}`, token),
  uploadConcurrency,
);
if (process.argv.includes("--deploy-only")) {
  const heads = await inspectObjects(
    url,
    token,
    serving.auxiliary.map((o) => o.key),
  );
  for (const item of serving.auxiliary) {
    const data = await readFile(item.path),
      h = heads.get(item.key)!;
    if (
      item.sha256 &&
      createHash("sha256").update(data).digest("hex") !== item.sha256
    )
      throw Error("Auxiliary manifest hash mismatch: " + item.key);
    if (
      h.status !== 200 ||
      Number(h.headers["content-length"]) !== item.size ||
      h.headers["x-sha256"] !== createHash("sha256").update(data).digest("hex")
    )
      throw Error("Unpublished auxiliary object: " + item.key);
  }
} else
  await publishAuxiliary(
    url,
    token,
    serving.auxiliary,
    out + "/auxiliary-publication.jsonl",
  );
uploadAgent.destroy();
if (process.argv.includes("--publish-only")) {
  await writeFile(
    out + "/publication.json",
    JSON.stringify(
      {
        generation: root.generation,
        corpusHash: root.corpusHash,
        objects: root.objects.length,
        auxiliaryObjects: serving.auxiliary.length,
        pairGeneration: serving.membership?.router.metadata.generation,
        metadataGeneration: serving.metadata?.generation,
        completedAt: new Date().toISOString(),
        immutableObjectsVerified: true,
      },
      null,
      2,
    ),
  );
  process.exit(0);
}
const entry = resolve(`work/columnar-deploy/${name}.ts`),
  config = resolve(`work/columnar-deploy/${name}.json`);
const packetBenchmark = process.argv.includes("--packet-benchmark");
const documentImport = root.documentPackages?.locators
    ? `import documents from ${JSON.stringify(sourceDir + "/documents.bin")};`
    : "",
  documentArgument = root.documentPackages?.locators
    ? "new Uint8Array(documents)"
    : "undefined";
if (packetBenchmark) {
  if (!root.directory || !root.documentPackages)
    throw Error("Packet benchmark requires a complete packet generation");
  await mkdir(sourceDir + "/bench/columnar", { recursive: true });
  await cp(
    "bench/columnar/packet-worker.ts",
    sourceDir + "/bench/columnar/packet-worker.ts",
  );
}
await writeFile(
  entry,
  packetBenchmark
    ? `${documentImport}import root from ${JSON.stringify(sourceDir + "/root.json")};import directory from ${JSON.stringify(sourceDir + "/directory.bin")};import {createPacketBenchmarkWorker} from ${JSON.stringify(sourceDir + "/bench/columnar/packet-worker.ts")};export default createPacketBenchmarkWorker(root as any,new Uint8Array(directory),${documentArgument});`
    : `${servingImports(serving, sourceDir)}${documentImport}import root from ${JSON.stringify(sourceDir + "/root.json")};${pairs ? `import pairs from ${JSON.stringify(sourceDir + "/pairs-root.json")};` : ""}${heads ? `import heads from ${JSON.stringify(sourceDir + "/heads-root.json")};import data from ${JSON.stringify(sourceDir + "/heads.bin")};` : ""}${root.directory ? `import directory from ${JSON.stringify(sourceDir + "/directory.bin")};` : ""}import {createColumnarWorker} from ${JSON.stringify(sourceDir + "/src/columnar/worker.ts")};export default createColumnarWorker(root as any,${pairs ? "pairs as any" : "undefined"},${heads ? "{root:heads as any,data:new Uint8Array(data)}" : "undefined"},${root.directory ? "new Uint8Array(directory)" : "undefined"},${documentArgument},${servingArguments(serving)});`,
);
await writeFile(
  config,
  JSON.stringify(
    {
      name,
      main: entry,
      compatibility_date: "2026-11-01",
      rules: [{ type: "Data", globs: ["**/*.bin"], fallthrough: true }],
      account_id: "8f088d4bd190caf693cc42bb8311fd7d",
      workers_dev: true,
      placement: { region: "aws:us-east-1" },
      r2_buckets: [{ binding: "INDEX", bucket_name: "work-search-demo" }],
      limits: { cpu_ms: 300000 },
      vars: {
        CACHE_NAMESPACE: process.env.CWS_NAMESPACE ?? name,
        PAGE_CACHE: "1",
      },
      observability: { enabled: true },
      version_metadata: { binding: "CF_VERSION_METADATA" },
    },
    null,
    2,
  ),
);
async function wrangler(args: string[], input?: string) {
  await new Promise<void>((ok, no) => {
    const p = spawn("yarn", ["wrangler", ...args], {
      stdio: ["pipe", "inherit", "inherit"],
    });
    p.stdin.end(input);
    p.once("error", no);
    p.once("exit", (code) =>
      code === 0 ? ok() : no(Error("Wrangler failed " + code)),
    );
  });
}
const deployRequestedAt = Date.now();
await wrangler(["deploy", "--config", config]);
await wrangler(
  ["secret", "put", "INTERNAL_TOKEN", "--config", config],
  await benchmarkToken(),
);
let deploymentProbe: any;
if (probeAt !== -1) {
  const contract = probeContract,
    attempts: any[] = [];
  for (let attempt = 0; ; attempt++) {
    const requestId = crypto.randomUUID(),
      startedAt = new Date().toISOString(),
      started = performance.now();
    const response = await fetch(
      `https://${name}.phulin.workers.dev/search?requestId=${requestId}`,
      {
        method: "POST",
        headers: {
          authorization: `Bearer ${token}`,
          "content-type": "application/json",
        },
        body: JSON.stringify({ q: contract.q, ...contract.options }),
        signal: AbortSignal.timeout(120000),
      },
    );
    const text = await response.text(),
      ms = performance.now() - started;
    let result: any;
    try {
      result = JSON.parse(text);
    } catch {
      result = { error: text.slice(0, 500) };
    }
    const version = result.telemetry?.version,
      current =
        result.generation === root.generation &&
        Date.parse(version?.timestamp) >= deployRequestedAt - 2000,
      correct =
        response.ok &&
        current &&
        result.results?.length === contract.oracle.length &&
        result.results.every((hit: any, i: number) => {
          const expected = contract.oracle[i];
          return (
            hit.id === expected.id &&
            Math.abs(hit.score - expected.score) <=
              1e-11 * Math.max(1, Math.abs(expected.score)) &&
            JSON.stringify([hit.title, hit.metadata]) ===
              JSON.stringify([expected.title, expected.metadata]) &&
            typeof hit.snippet === "string"
          );
        });
    attempts.push({
      requestId,
      startedAt,
      ms,
      status: response.status,
      current,
      correct,
      result,
      bytes: Buffer.byteLength(text),
    });
    deploymentProbe = {
      deployRequestedAt: new Date(deployRequestedAt).toISOString(),
      q: contract.q,
      options: contract.options,
      attempts,
      condition:
        "Search before any health/warmup request after actual deployment; shared namespace as configured; opaque R2 caches uncontrolled",
    };
    await writeFile(
      `work/columnar-deploy/${name}-first-search.json`,
      JSON.stringify(deploymentProbe, null, 2),
    );
    if (correct) break;
    if (current || attempt === 29)
      throw Error("Deployment first-search probe failed");
    await new Promise((r) => setTimeout(r, 2000));
  }
}
// Deployment acknowledgement can precede workers.dev route propagation.
for (let attempt = 0; ; attempt++) {
  const healthy = await fetch(`https://${name}.phulin.workers.dev/health`)
    .then(async (r) => {
      if (!r.ok) return false;
      const health = await r.json();
      return packetBenchmark
        ? (health as any).generation === root.generation
        : matchesServingHealth(serving, health);
    })
    .catch(() => false);
  if (healthy) break;
  if (attempt === 29) throw Error("Deployment health did not converge " + name);
  await new Promise((r) => setTimeout(r, 2000));
}
async function hashes(dir: string): Promise<Record<string, string>> {
  const result: Record<string, string> = {};
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = dir + "/" + entry.name;
    if (entry.isDirectory())
      for (const [k, v] of Object.entries(await hashes(path)))
        result[entry.name + "/" + k] = v;
    else
      result[entry.name] = createHash("sha256")
        .update(await readFile(path))
        .digest("hex");
  }
  return result;
}
const sourceFiles = await hashes(sourceDir),
  sourceHash = createHash("sha256")
    .update(JSON.stringify(sourceFiles))
    .digest("hex");
await writeFile(
  `work/columnar-deploy/${name}-manifest.json`,
  JSON.stringify(
    {
      name,
      root: resolve(out + "/root.json"),
      generation: root.generation,
      corpusHash: root.corpusHash,
      deployedAt: new Date().toISOString(),
      namespace: process.env.CWS_NAMESPACE ?? name,
      sourceHash,
      sourceFiles,
      deploymentProbe,
      packageSha256: createHash("sha256")
        .update(await readFile("package.json"))
        .digest("hex"),
      lockSha256: createHash("sha256")
        .update(await readFile("yarn.lock"))
        .digest("hex"),
    },
    null,
    2,
  ),
);
