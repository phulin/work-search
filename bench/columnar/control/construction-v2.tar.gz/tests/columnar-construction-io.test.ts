import { expect, it } from "vitest";
import { gzipSync } from "node:zlib";
import { CorpusSource } from "../src/columnar/construction/source.js";
import { concat, u32 } from "../src/columnar/format.js";
import { crc32 } from "../src/format/codec.js";
import { planMerges } from "../scripts/construction-merge-plan.js";
import type { Run } from "../src/columnar/construction/runs.js";

function archive(bodies: string[], gaps = false) {
  const generation = "a".repeat(64),
    contents: Uint8Array[] = [],
    infos: Uint8Array[] = [],
    pointers: number[] = [];
  let contentAt = 0,
    infoAt = 0;
  for (const [i, body] of bodies.entries()) {
    const content = gzipSync(body),
      info = new TextEncoder().encode(JSON.stringify({ id: String(i) }));
    pointers.push(
      0,
      contentAt,
      content.length,
      crc32(content),
      0,
      infoAt,
      info.length,
      crc32(info),
    );
    contents.push(content);
    infos.push(info);
    contentAt += content.length;
    infoAt += info.length;
    if (gaps) {
      contents.push(new Uint8Array(100));
      contentAt += 100;
    }
  }
  const objects = new Map([
      [`${generation}/content-0.bin`, concat(contents)],
      [`${generation}/info-0.bin`, concat(infos)],
      [`${generation}/contentmap-0.bin`, u32(pointers)],
    ]),
    reads: { key: string; length: number }[] = [],
    bucket = {
      async get(key: string, options: any) {
        const bytes = objects.get(key)!;
        const range = bytes.slice(
          options.range.offset,
          options.range.offset + options.range.length,
        );
        reads.push({ key, length: range.length });
        return {
          customMetadata: { generation },
          size: bytes.length,
          arrayBuffer: async () => Uint8Array.from(range).buffer,
        };
      },
    } as unknown as R2Bucket;
  return {
    reads,
    source: new CorpusSource(bucket, {
      format: "R2-source-v1",
      documents: bodies.length,
      parts: [
        {
          part: 0,
          generation,
          first: 0,
          count: bodies.length,
          inputSha256: "b".repeat(64),
        },
      ],
    }),
  };
}

it("keeps source reads coalesced after each bounded prefetch window fills", async () => {
  const bodies = Array.from({ length: 12 }, () => "alpha beta"),
    { source, reads } = archive(bodies),
    pointers = await source.pointers(0, bodies.length),
    recordBytes = gzipSync(bodies[0]).length + 10;
  await source.prefetch(pointers, recordBytes * 4);
  for (let i = 0; i < bodies.length; i++) {
    expect(await source.document(i, pointers, i)).toMatchObject({
      id: String(i),
      body: bodies[i],
      doc: i,
    });
    expect(
      source.buffered.reduce((n, b) => n + b.bytes.length, 0),
    ).toBeLessThanOrEqual(recordBytes * 4);
  }
  // Three/four bounded windows instead of an initial window and 16 single-doc
  // GETs. The final IDs have one extra byte, so the last window splits in two.
  expect(reads.length).toBe(9);
});

it("resumes batching after an oversized record and preserves sparse source pointers", async () => {
  const large = Array.from({ length: 1000 }, (_, i) => String(i * 7919)).join(
      " ",
    ),
    bodies = [large, ...Array.from({ length: 12 }, () => "small")];
  for (const gaps of [false, true]) {
    const { source, reads } = archive(bodies, gaps),
      pointers = await source.pointers(0, bodies.length);
    await source.prefetch(pointers, 400);
    for (let i = 0; i < bodies.length; i++) {
      expect((await source.document(i, pointers, i)).body).toBe(bodies[i]);
      expect(
        source.buffered.reduce((n, b) => n + b.bytes.length, 0),
      ).toBeLessThanOrEqual(400);
    }
    expect(reads.length).toBeLessThan(1 + 2 * bodies.length);
    expect(
      reads.filter((r) => r.key.endsWith("/content-0.bin") && r.length > 400),
    ).toHaveLength(1);
  }
});

it("avoids an extra complete merge pass while keeping bounded fan-in and lexical parallelism", () => {
  const runs: Run[] = Array.from({ length: 96 }, (_, i) => ({
    first: i,
    next: i + 1,
    count: 1,
    bodyTokens: 1,
    titleTokens: 0,
    chunks: [
      {
        key: String(i),
        sha256: "a".repeat(64),
        size: 100,
        firstWord: String(i).padStart(3, "0"),
        lastWord: "zzz",
      },
    ],
  }));
  const plan = planMerges(runs, 32);
  expect(plan.lexical).toBe(true);
  expect(new Set(plan.jobs.map((j) => j.group)).size).toBe(6);
  expect(new Set(plan.jobs.map((j) => j.lexical)).size).toBe(32);
  for (let lexical = 0; lexical < 32; lexical++) {
    const jobs = plan.jobs.filter((j) => j.lexical === lexical);
    expect(
      jobs.flatMap((j) =>
        Array.from({ length: j.endRun - j.firstRun }, (_, i) => j.firstRun + i),
      ),
    ).toEqual(runs.map((_, i) => i));
    expect(jobs.every((j) => j.endRun - j.firstRun <= 16)).toBe(true);
  }
  for (const width of [1, 8, 32, 128]) {
    const p = planMerges(runs, width);
    expect(p.jobs.every((j) => j.endRun - j.firstRun <= 16)).toBe(true);
  }
});
