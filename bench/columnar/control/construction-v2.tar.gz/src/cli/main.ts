import { openIndex, PagedIndex } from "../format/paged.js";
import { pageIndex } from "../builder/page-index.js";
import { readFile, writeFile, mkdir, copyFile } from "node:fs/promises";
import { resolve, join } from "node:path";
import { spawnSync } from "node:child_process";
import { build } from "../builder/build.js";
import { generate } from "./generate.js";
import { BinaryIndex, VERSION, SUPPORTED_VERSIONS } from "../format/index.js";
import { FileStorage } from "../storage/filesystem.js";
import { search } from "../query/engine.js";
import { upload } from "./upload.js";
import { Miniflare } from "miniflare";
const [command, ...args] = process.argv.slice(2),
  arg = (key: string, fallback: string) => {
    const i = args.indexOf("--" + key);
    return i < 0 ? fallback : args[i + 1];
  };
function wrangler(args: string[]) {
  const r = spawnSync(
    process.execPath,
    ["node_modules/wrangler/bin/wrangler.js", ...args],
    { stdio: "inherit" },
  );
  if (r.status !== 0) throw new Error("Wrangler command failed");
}
const out = arg("out", "indexes/current");
async function manifest() {
  const m = JSON.parse(await readFile(join(out, "manifest.json"), "utf8"));
  const { createHash } = await import("node:crypto");
  const binary = await readFile(join(out, "bundle.bin"));
  const index = openIndex(binary);
  if (
    (m.layout === "paged"
      ? !(index instanceof PagedIndex) || index.root.version !== m.format
      : index.paged) ||
    !(m.layout === "paged" || SUPPORTED_VERSIONS.includes(m.format)) ||
    (m.layout !== "paged" && new BinaryIndex(binary).format !== m.format) ||
    createHash("sha256").update(binary).digest("hex") !== m.bundleSha256 ||
    openIndex(binary).generation !== m.generation
  )
    throw new Error("Bundle/manifest mismatch");
  for (const o of m.objects) {
    const bytes = await readFile(join(out, "objects", o.key));
    if (
      bytes.length !== o.size ||
      createHash("sha256").update(bytes).digest("hex") !== o.sha256
    )
      throw new Error("Object checksum mismatch: " + o.key);
  }
  return m;
}
async function pagedOptions() {
  return {
    localTables: args.includes("--local-tables"),
    budget: Number(arg("budget-mib", "8")) * 1048576,
    hotDescriptors: Number(arg("hot-descriptors", "0")),
    embedPostings: args.includes("--embed-postings"),
    inlineTiny: args.includes("--inline-tiny"),
    optimizationStep:
      args.includes("--hot-descriptors") || args.includes("--inline-tiny")
        ? 6
        : 0,
    workload: args.includes("--workload")
      ? (await readFile(arg("workload", ""), "utf8"))
          .split(/\r?\n/)
          .filter(Boolean)
      : [],
  };
}
try {
  if (command === "generate") {
    await mkdir("data", { recursive: true });
    await generate(
      arg("output", "data/sample.jsonl"),
      Number(arg("count", "100")),
      Number(arg("seed", "42")),
    );
  } else if (command === "page") {
    console.log(
      JSON.stringify(
        await pageIndex(
          arg("source", "indexes/current"),
          out,
          await pagedOptions(),
        ),
        null,
        2,
      ),
    );
  } else if (command === "build") {
    const strategy = arg("strategy", "smallest");
    if (!["smallest", "workload", "mixed"].includes(strategy))
      throw new Error("Unknown strategy");
    const workload = args.includes("--workload")
      ? (await readFile(arg("workload", ""), "utf8"))
          .split(/\r?\n/)
          .filter(Boolean)
      : [];
    const paged = arg("layout", "bundled") === "paged";
    const builtOut = paged ? out + ".staging" : out;
    const built = await build({
      input: arg("input", "data/sample.jsonl"),
      out: builtOut,
      pagedStaging: paged,
      budget: Number(arg("budget-mib", "8")) * 1024 * 1024,
      strategy: strategy as "smallest" | "workload" | "mixed",
      workload,
      chunkDocs: Number(arg("chunk-docs", "5000")),
    });
    const result = paged
      ? await pageIndex(builtOut, out, await pagedOptions())
      : built;
    await copyFile(join(out, "bundle.bin"), "data/bundle.bin");
    console.log(JSON.stringify(result, null, 2));
  } else if (command === "search") {
    const index = openIndex(await readFile(join(out, "bundle.bin")));
    console.log(
      JSON.stringify(
        await search(
          index,
          new FileStorage(join(out, "objects")),
          arg("query", ""),
          {
            competitivePositions: args.includes("--competitive-positions"),
            r2LatencyMs: Number(arg("r2-latency-ms", "20")),
            r2BandwidthMiB: Number(arg("r2-bandwidth-mib", "50")),
            mode: arg("mode", "and") as "and" | "or",
            limit: Number(arg("limit", "20")),
            metadata: args.includes("--metadata"),
            exactTotal:
              args.includes("--total") && !args.includes("--no-total"),
          },
        ),
        null,
        2,
      ),
    );
  } else if (command === "seed" || command === "deploy" || command === "dev") {
    const m = await manifest(),
      remote = command === "deploy";
    if (remote) await upload(out, arg("bucket", "worker-search-index"), m);
    else {
      const mf = new Miniflare({
        modules: true,
        script: 'export default {fetch(){return new Response("seed");}}',
        r2Buckets: { INDEX: arg("bucket", "worker-search-index") },
        r2Persist: ".wrangler/state/v3/r2",
      });
      try {
        const bucket = await mf.getR2Bucket("INDEX");
        for (const o of m.objects)
          await bucket.put(o.key, await readFile(join(out, "objects", o.key)), {
            customMetadata: { generation: m.generation, sha256: o.sha256 },
          });
      } finally {
        await mf.dispose();
      }
    }
    await copyFile(join(out, "bundle.bin"), "data/bundle.bin");
    if (remote) wrangler(["deploy"]);
    else if (command === "dev") wrangler(["dev"]);
  } else if (command === "verify") {
    console.log((await manifest()).generation);
  } else
    throw new Error(
      "Commands: generate, build, search, seed, dev, deploy, verify",
    );
} catch (e) {
  console.error(e instanceof Error ? e.message : e);
  process.exitCode = 1;
}
